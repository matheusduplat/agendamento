<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class loja extends Model
{
    protected $table = 'loja';
    protected $fillable = [
        'id',
       'nome',
    ];
    





    }
    
